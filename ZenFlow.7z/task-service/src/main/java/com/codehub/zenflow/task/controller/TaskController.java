package com.codehub.zenflow.task.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("api/task")
public class TaskController
{
	@GetMapping("/home")
	public ResponseEntity<String> getHome()
	{
		return ResponseEntity.ok().body( "Home Page - Task Service" );
	}

}
