package com.codehub.zenflow.task.config;

import com.codehub.zenflow.task.config.filters.XAuthenticatedUserFilter;
import jakarta.servlet.http.HttpServletRequest;
import org.apache.commons.lang.StringUtils;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.authorization.AuthorizationDecision;
import org.springframework.security.authorization.AuthorizationManager;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.access.intercept.RequestAuthorizationContext;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;

import java.util.Collections;
import java.util.List;

@Configuration
@EnableWebSecurity
public class SecurityConfiguration
{

	private final String AUTHENTICATED_USER = "X-Authenticated-User";

	private final String AUTHENTICATED_ROLE = "X-Authenticated-Role";

	@Bean
	public SecurityFilterChain securityFilterChain( HttpSecurity http) throws Exception {
		http.csrf(AbstractHttpConfigurer::disable)
				.authorizeHttpRequests(request -> request
						.requestMatchers( "/api/task/**" ).access( hasValidCustomHeader() )
						.anyRequest().authenticated())
				.formLogin(AbstractHttpConfigurer::disable)
				.httpBasic(AbstractHttpConfigurer::disable)
				.sessionManagement(session -> session.sessionCreationPolicy( SessionCreationPolicy.STATELESS));
//				.addFilterBefore(new XAuthenticatedUserFilter(), UsernamePasswordAuthenticationFilter.class);

		return http.build();
	}

	private AuthorizationManager<RequestAuthorizationContext> hasValidCustomHeader() {
		return (authentication, context) -> {
			HttpServletRequest request = context.getRequest();
			String username = request.getHeader( AUTHENTICATED_USER );
			String role = request.getHeader( AUTHENTICATED_ROLE );

			// ✅ Ensure authentication check (optional but recommended)
			boolean isAuthenticated = authentication != null && authentication.get().isAuthenticated();
			boolean hasValidHeader = username != null && !username.isEmpty();
			boolean hasValidRole = role != null && StringUtils.isNotBlank( role );
			if (isAuthenticated && hasValidHeader && hasValidRole) {
//				LOGGER.debug( "Request Authenticated:: X-Authenticated-USer: {}, X-Authenticated-Role: {}", username, role );
				// Convert role to a list of GrantedAuthority
				List<GrantedAuthority> authorities = Collections.singletonList(new SimpleGrantedAuthority("ROLE_"+role));

				// Create Authentication object
				Authentication newAuth = new UsernamePasswordAuthenticationToken(username, null, authorities);

				// Store it in Security Context
				SecurityContextHolder.getContext().setAuthentication(newAuth);
			}
			else
			{
//				LOGGER.error( "Authentication Header in not found: X-Authenticated-USer {}, X-Authenticated-Role {}",
//						username, role );
			}

			return new AuthorizationDecision(isAuthenticated && hasValidHeader && hasValidRole);
		};
	}
}
