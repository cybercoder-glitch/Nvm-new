package com.codehub.zenflow.auth.service.dto;

/**
 * Data Transfer Object for user service requests.
 */
public class UserServiceRequest
{
    /**
     * The username of the user.
     */
	private String username;

    /**
     * The password of the user.
     */
	private String password;

    /**
     * The role of the user.
     */
	private String userRole;

    /**
     * The email ID of the user.
     */
	private String userEmailId;

    /**
     * The new password for the user.
     */
	private String newUserPassword;

	private String profileName;

	private String firstName;

	private String lastName;

    /**
     * Gets the username of the user.
     *
     * @return the username
     */
	public String getUsername()
	{
		return username;
	}

    /**
     * Sets the username of the user.
     *
     * @param username the username
     */
	public void setUsername( String username )
	{
		this.username = username;
	}

    /**
     * Gets the password of the user.
     *
     * @return the password
     */
	public String getPassword()
	{
		return password;
	}

    /**
     * Sets the password of the user.
     *
     * @param password the password
     */
	public void setPassword( String password )
	{
		this.password = password;
	}

    /**
     * Gets the role of the user.
     *
     * @return the user role
     */
	public String getUserRole()
	{
		return userRole;
	}

    /**
     * Sets the role of the user.
     *
     * @param userRole the user role
     */
	public void setUserRole( String userRole )
	{
		this.userRole = userRole;
	}

    /**
     * Gets the email ID of the user.
     *
     * @return the user email ID
     */
	public String getUserEmailId()
	{
		return userEmailId;
	}

    /**
     * Sets the email ID of the user.
     *
     * @param userEmailId the user email ID
     */
	public void setUserEmailId( String userEmailId )
	{
		this.userEmailId = userEmailId;
	}

    /**
     * Gets the new password for the user.
     *
     * @return the new user password
     */
	public String getNewUserPassword()
	{
		return newUserPassword;
	}

    /**
     * Sets the new password for the user.
     *
     * @param newUserPassword the new user password
     */
	public void setNewUserPassword( String newUserPassword )
	{
		this.newUserPassword = newUserPassword;
	}

	public String getProfileName()
	{
		return profileName;
	}

	public void setProfileName( String profileName )
	{
		this.profileName = profileName;
	}

	public String getFirstName()
	{
		return firstName;
	}

	public void setFirstName( String firstName )
	{
		this.firstName = firstName;
	}

	public String getLastName()
	{
		return lastName;
	}

	public void setLastName( String lastName )
	{
		this.lastName = lastName;
	}

	@Override
	public String toString()
	{
		return "UserServiceRequest{" +
				"username='" + username + '\'' +
				", userRole='" + userRole + '\'' +
				", userEmailId='" + userEmailId + '\'' +
				", newUserPassword='" + newUserPassword + '\'' +
				", profileName='" + profileName + '\'' +
				", firstName='" + firstName + '\'' +
				", lastName='" + lastName + '\'' +
				'}';
	}
}
