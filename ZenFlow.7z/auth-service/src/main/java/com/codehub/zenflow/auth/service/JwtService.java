package com.codehub.zenflow.auth.service;

import com.codehub.zenflow.auth.utils.JwtUtils;
import io.jsonwebtoken.Jwts;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * Service class for handling JWT operations such as token generation and validation.
 */
@Service
public class JwtService
{

	private static final Logger LOGGER = LogManager.getLogger( JwtService.class );

    /**
     * Constant for converting seconds to milliseconds.
     */
	public static final int MILLIS = 1000;
	@Autowired
	private JwtUtils jwtUtils;

    /**
     * Generates a JWT token for the given username and role.
     *
     * @param username the username for which the token is generated
     * @param role the role of the user
     * @return the generated JWT token
     */
	public String generateToken(String username, String role) {
		LOGGER.debug( "Token generation in progress with the role: {}", role );
		Map<String, Object> claims = new HashMap<>();
		claims.put( "role", role );
		return Jwts.builder()
				.claims()
				.add( claims )
				.subject(username)
				.issuedAt(new Date(System.currentTimeMillis()))
				.expiration(new Date(System.currentTimeMillis() + (jwtUtils.getExpiration() * MILLIS) ))
				.and()
				.signWith(jwtUtils.getSigningKey())
				.compact();
	}

    /**
     * Validates the given JWT token against the provided user details.
     *
     * @param token the JWT token to validate
     * @param userDetails the user details to validate against
     * @return true if the token is valid, false otherwise
     */
//	public boolean validateToken(String token, UserDetails userDetails) {
//		final String userName = jwtUtils.extractUserName(token);
//		return (userName.equals(userDetails.getUsername()) && !jwtUtils.isTokenExpired(token));
//	}
}
