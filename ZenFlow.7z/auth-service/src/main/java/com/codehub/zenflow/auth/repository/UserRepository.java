package com.codehub.zenflow.auth.repository;

import com.codehub.zenflow.auth.domain.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Optional;

/**
 * Repository interface for accessing user data.
 */
@Repository
public interface UserRepository extends JpaRepository<User,Long>
{
    /**
     * Finds a user by their username.
     *
     * @param username the username of the user
     * @return an Optional containing the user if found, or empty if not found
     */
	Optional<User> findByUsername(String username);

    /**
     * Finds a user by their username and email.
     *
     * @param username the username of the user
     * @param userEmail the email of the user
     * @return an Optional containing the user if found, or empty if not found
     */
	@Query("SELECT u FROM User u WHERE u.username = :username AND u.userEmail = :userEmail")
	Optional<User> findByUsernameAndEmailId( @Param( "username" ) String username, @Param( "userEmail" ) String userEmail );
}
