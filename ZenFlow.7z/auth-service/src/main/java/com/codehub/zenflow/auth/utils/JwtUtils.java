package com.codehub.zenflow.auth.utils;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Component;

import javax.crypto.SecretKey;
import java.io.InputStream;
import java.security.KeyStore;
import java.util.Date;
import java.util.function.Function;

/**
 * Utility class for handling JWT operations such as extracting claims and validating tokens.
 */
@Component
public class JwtUtils {

	private static final Logger LOGGER = LogManager.getLogger( JwtUtils.class);

	public static final String KEY_TYPE = "PKCS12";

	@Value("${jwt.expiration}")
	private Long expiration;

	@Value("${jwt.keystore.location}")
	private String keystoreLocation;

	@Value("${jwt.keystore.alias}")
	private String keystoreAlias;

	@Value("${jwt.keystore.password}")
	private String keystorePassword;

    /**
     * Retrieves the signing key from the keystore.
     *
     * @return the signing key
     * @throws RuntimeException if an error occurs while loading the keystore
     */
	public SecretKey getSigningKey() {
		try ( InputStream inputStream = new ClassPathResource(keystoreLocation).getInputStream()) {
			KeyStore keyStore = KeyStore.getInstance( KEY_TYPE );
			keyStore.load(inputStream, keystorePassword.toCharArray());
			return (SecretKey) keyStore.getKey(keystoreAlias, keystorePassword.toCharArray());
		} catch (Exception e) {
			LOGGER.error( "Error creating signing key: {}", e.getMessage() );
			LOGGER.trace( "Error creating signing key: {}", e.getCause().getMessage() );
			throw new RuntimeException("Error loading keystore", e);
		}
	}

    /**
     * Gets the expiration time for the JWT.
     *
     * @return the expiration time in milliseconds
     */
	public Long getExpiration()
	{
		return expiration;
	}

    /**
     * Extracts the username from the JWT token.
     *
     * @param token the JWT token
     * @return the username
     */
	public String extractUserName(String token) {
		// extract the username from jwt token
		return extractClaim(token, Claims::getSubject);
	}

	/**
     * Extracts the role from the JWT token.
     *
     * @param token the JWT token
     * @return the role
	 */
	public String extractUserRole(String token) {
		return extractClaim(token, claims -> claims.get("role", String.class));
	}

    /**
     * Extracts a specific claim from the JWT token.
     *
     * @param token the JWT token
     * @param claimResolver a function to resolve the claim
     * @param <T> the type of the claim
     * @return the claim
     */
	public <T> T extractClaim(String token, Function<Claims, T> claimResolver) {
		final Claims claims = extractAllClaims(token);
		return claimResolver.apply(claims);
	}

    /**
     * Extracts all claims from the JWT token.
     *
     * @param token the JWT token
     * @return the claims
     */
	public Claims extractAllClaims(String token) {
		return Jwts.parser()
				.verifyWith(getSigningKey())
				.build()
				.parseSignedClaims(token)
				.getPayload();
	}

    /**
     * Checks if the JWT token is expired.
     *
     * @param token the JWT token
     * @return true if the token is expired, false otherwise
     */
	public boolean isTokenExpired( String token ) {
		return extractExpiration(token).before(new Date());
	}

    /**
     * Extracts the expiration date from the JWT token.
     *
     * @param token the JWT token
     * @return the expiration date
     */
	public Date extractExpiration(String token) {
		return extractClaim(token, Claims::getExpiration);
	}
}