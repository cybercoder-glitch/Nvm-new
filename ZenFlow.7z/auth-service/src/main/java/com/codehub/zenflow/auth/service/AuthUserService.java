package com.codehub.zenflow.auth.service;

import com.codehub.zenflow.auth.domain.User;
import com.codehub.zenflow.auth.kafka.KafkaProducerService;
import com.codehub.zenflow.auth.repository.UserRepository;
import com.codehub.zenflow.auth.service.dto.UserServiceRequest;
import com.codehub.zenflow.kafka.event.UserCreateEvent;
import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import java.util.Optional;

/**
 * Service class for handling user authentication and management.
 */
@Service
public class AuthUserService
{

	private static final Logger LOGGER = LogManager.getLogger( AuthUserService.class);

	@Autowired
	private UserRepository userRepo;

	@Autowired
	private PasswordEncoder passwordEncoder;

	@Autowired
	private AuthenticationManager authenticationManager;

	@Autowired
	private JwtService jwtService;

	@Autowired
	private KafkaProducerService kafkaProducerService;
    /**
     * Retrieves all users.
     *
     * @return a list of all users
     */
	public List<User> getUsers()
	{
		return userRepo.findAll();
	}

    /**
     * Retrieves a user by their ID.
     *
     * @param id the ID of the user
     * @return a ResponseEntity containing the user if found, or a not found message
     */
	public ResponseEntity<String> getUserById( Long id )
	{
		Optional<User> user = userRepo.findById( id );
		ResponseEntity<String> response = new ResponseEntity<>( "User not found!", HttpStatus.NOT_FOUND );
		if ( user.isPresent() )
		{
			response = new ResponseEntity<>( "User: \n"+user.get(), HttpStatus.OK );
		}
		return response;
	}

    /**
     * Registers a new user.
     *
     * @param request the user service request containing user details
     * @return a ResponseEntity indicating the result of the registration
     */
	public ResponseEntity<String> registerUserData( UserServiceRequest request )
	{
		ResponseEntity<String> response;
		if ( StringUtils.isNotBlank( request.getUsername() )
				&& StringUtils.isNotBlank( request.getPassword() ) && !isUserExists( request ) )
		{
			User user = new User();
			user.setUsername( request.getUsername() );
			user.setPassword( passwordEncoder.encode( request.getPassword() ) );
			user.setUserRole( request.getUserRole().toUpperCase() );
			user.setUserEmail( request.getUserEmailId() );
			User save = userRepo.save( user );
			response = new ResponseEntity<>( "User Created : "+ save, HttpStatus.CREATED );

			UserCreateEvent event = prepareUserCreateEvent( request, save );
			kafkaProducerService.publishEvent( event );
		}
		else
		{
			response = new ResponseEntity<>( "Username or Password required!", HttpStatus.BAD_REQUEST );
		}
		return response;
	}

	private UserCreateEvent prepareUserCreateEvent( UserServiceRequest request, User save )
	{
		UserCreateEvent event = new UserCreateEvent();
		event.setUserId( save.getId() );
		event.setUsername( save.getUsername() );
		event.setEmail( save.getUserEmail() );
		event.setUserRole( save.getUserRole() );
		event.setProfileName( request.getProfileName() );
		event.setFirstName( request.getFirstName() );
		event.setLastName( request.getLastName() );
		return event;
	}

	/**
     * Logs in a user.
     *
     * @param request the user service request containing login details
     * @return a ResponseEntity indicating the result of the login attempt
     */
	public ResponseEntity<Map<String,String>> loginUserData( UserServiceRequest request )
	{
		ResponseEntity<Map<String,String>> response = null;
		if (!isRequestValid(request)) {
			response = ResponseEntity.badRequest().body(Map.of("status","Username and password are required!"));
		}
		else
		{
			response = isUserRegistered( request );
		}
		return response;
	}

    /**
     * Validates the user service request.
     *
     * @param request the user service request
     * @return true if the request is valid, false otherwise
     */
	private boolean isRequestValid( UserServiceRequest request )
	{
		return StringUtils.isNotBlank( request.getUsername() )
			&& StringUtils.isNotBlank( request.getPassword() );
	}

    /**
     * Checks if a user is registered.
     *
     * @param request the user service request
     * @return a ResponseEntity indicating the result of the check
     */
	private ResponseEntity<Map<String,String>> isUserRegistered( UserServiceRequest request )
	{
		LOGGER.info("INFO Log Message");
		LOGGER.warn("WARN Log Message");
		LOGGER.error("ERROR Log Message");
		LOGGER.debug("DEBUG Log Message");
		Optional<User> user = userRepo.findByUsername( request.getUsername() );
		ResponseEntity<Map<String,String>> response = ResponseEntity.status( HttpStatus.UNAUTHORIZED ).body( Map.of("status","Access not permitted") );
		if (user.isEmpty()) {
			response = ResponseEntity.status(HttpStatus.NOT_FOUND).body(Map.of("status","User not found!"));
		}
		else if ( isUserAuthenticated( request ) )
		{
//			response = user.map( value -> ResponseEntity.ok().body( "User Found "+value ) ).get();
//			response = ResponseEntity.ok().body("token: "+ jwtService.generateToken( user.get().getUsername(), user.get().getUserRole() ) );
//			response = ResponseEntity
//					.ok()
//					.body( "User verified \nAccesss Granted \nToken: " +
//							jwtService.generateToken( user.get().getUsername(),	user.get().getUserRole() ) );
			response = ResponseEntity.ok()
									 .header( HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE )
									 .body( Map.of("token",jwtService.generateToken( user.get().getUsername(), user.get().getUserRole() )) );
		}
		return response;
	}

    /**
     * Authenticates a user.
     *
     * @param request the user service request
     * @return true if the user is authenticated, false otherwise
     */
	private boolean isUserAuthenticated( UserServiceRequest request )
	{
		ResponseEntity<String> response;
		Authentication authentication = authenticationManager.authenticate(
				new UsernamePasswordAuthenticationToken( request.getUsername(), request.getPassword() ) );
		return authentication.isAuthenticated();
	}

    /**
     * Recovers a user account.
     *
     * @param request the user service request
     * @return a ResponseEntity indicating the result of the recovery attempt
     */
	public ResponseEntity<String> recoverUserAccount( UserServiceRequest request )
	{
		if ( isUserExists( request ) )
		{
			Optional<User> user = userRepo.findByUsernameAndEmailId( request.getUsername(), request.getUserEmailId() );
			if ( user.isPresent() )
			{
				user.get().setPassword( passwordEncoder.encode(request.getNewUserPassword() ) );
				userRepo.save( user.get() );
				return new ResponseEntity<>( "Password Updated!", HttpStatus.OK );
			}
		}
		return new ResponseEntity<>( "User does not exist", HttpStatus.UNAUTHORIZED );
	}

    /**
     * Checks if a user exists.
     *
     * @param serviceRequest the user service request
     * @return true if the user exists, false otherwise
     */
	private boolean isUserExists( UserServiceRequest serviceRequest )
	{
		return userRepo.findByUsername( serviceRequest.getUsername() ).isPresent();
	}

    /**
     * Verifies a user account.
     *
     * @param request the user service request
     * @return a ResponseEntity indicating the result of the verification attempt
     */
	public ResponseEntity<String> verifyUserAccount( UserServiceRequest request )
	{
		if ( isUserExists( request ) )
		{
			Optional<User> user = userRepo.findByUsernameAndEmailId( request.getUsername(), request.getUserEmailId() );
			if ( user.isPresent() )
			{
				return ResponseEntity
						.ok( "Username: "+ user.get().getUsername() +
								"\nEmail Id: "+ user.get().getUserEmail() +
								"\nUser Role: "+ user.get().getUserRole() );
			}
		}
		return ResponseEntity.status( HttpStatus.UNAUTHORIZED ).body( "User does not exist" );
	}
}
