package com.codehub.zenflow.auth.config;

//import com.codehub.zenflow.auth.utils.JwtAuthenticationFilter;
import jakarta.servlet.http.HttpServletRequest;
import lombok.extern.java.Log;
import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.authorization.AuthorizationDecision;
import org.springframework.security.authorization.AuthorizationManager;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.access.intercept.RequestAuthorizationContext;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.cors.CorsConfiguration;

import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.util.Base64;
import java.util.Collections;
import java.util.List;

/**
 * Security configuration class for setting up Spring Security.
 */
@Configuration
@EnableWebSecurity
@EnableMethodSecurity
public class SecurityConfiguration
{

	private static final Logger LOGGER = LogManager.getLogger(SecurityConfiguration.class);

	public static final String AUTHENTICATED_USER = "X-Authenticated-User";

	public static final String AUTHENTICATED_ROLE = "X-Authenticated-Role";

	@Autowired
	private UserDetailsService authUserDetailsService;

//	@Autowired
//	private JwtAuthenticationFilter jwtAuthenticationFilter;

    /**
     * Configures the authentication provider with user details service and password encoder.
     *
     * @return the configured AuthenticationProvider
     */
	@Bean
	public AuthenticationProvider authProvider()
	{
		DaoAuthenticationProvider daoAuthenticationProvider = new DaoAuthenticationProvider();
		daoAuthenticationProvider.setUserDetailsService( authUserDetailsService );
		daoAuthenticationProvider.setPasswordEncoder( new BCryptPasswordEncoder() );
		return daoAuthenticationProvider;
	}

    /**
     * Configures the authentication manager.
     *
     * @param configuration the AuthenticationConfiguration
     * @return the configured AuthenticationManager
     * @throws Exception if an error occurs during configuration
     */
	@Bean
	public AuthenticationManager authenticationManager( AuthenticationConfiguration configuration ) throws Exception
	{
		return configuration.getAuthenticationManager();
	}

    /**
     * Configures the security filter chain.
     *
     * @param http the HttpSecurity object
     * @return the configured SecurityFilterChain
     * @throws Exception if an error occurs during configuration
     */
	@Bean
	public SecurityFilterChain filterChain( HttpSecurity http ) throws Exception
	{
		LOGGER.debug( "Request reached Security Configuration" );
		http.csrf( AbstractHttpConfigurer::disable )
			.authorizeHttpRequests( request -> request
					.requestMatchers( HttpMethod.POST,
							"/api/auth/signup", "/api/auth/login", "/api/auth/recover" ).permitAll()
//					.requestMatchers( "/api/auth/**" ).hasVariable(  )
					.requestMatchers( "/api/auth/**" ).access( hasValidCustomHeader() )
					.anyRequest().authenticated() )
			.formLogin( AbstractHttpConfigurer::disable )
			.httpBasic( Customizer.withDefaults() )
			.sessionManagement( session -> session.sessionCreationPolicy( SessionCreationPolicy.STATELESS ) );
//			.addFilterBefore( jwtAuthenticationFilter, UsernamePasswordAuthenticationFilter.class );
		return http.build();
	}

	private AuthorizationManager<RequestAuthorizationContext> hasValidCustomHeader() {
		return (authentication, context) -> {
			HttpServletRequest request = context.getRequest();
			String username = request.getHeader( AUTHENTICATED_USER );
			String role = request.getHeader( AUTHENTICATED_ROLE );
//			String encodedCert = request.getHeader( "X-Client-Cert" );
//
//			boolean hasValidCert = false;
//
//			if (encodedCert == null || encodedCert.isEmpty()) {
//				return new AuthorizationDecision(false);
//			}
//
//			try {
//				byte[] certBytes = Base64.getDecoder().decode(encodedCert);
//				CertificateFactory cf = CertificateFactory.getInstance("X.509");
//				X509Certificate clientCert = (X509Certificate) cf.generateCertificate(new java.io.ByteArrayInputStream(certBytes));
//
//				// Validate certificate details (e.g., check subject and issuer)
//				String subjectDN = clientCert.getSubjectX500Principal().getName();
//				String issuerDN = clientCert.getIssuerX500Principal().getName();
//
//				// Example validation: Ensure the certificate was issued by our trusted CA and has expected subject.
//				boolean valid = subjectDN.contains("CN=zenflow-api-gateway") && issuerDN.contains("CN=Zenflow-CA");
////				return new AuthorizationDecision(valid);
//				hasValidCert = valid;
//			} catch (Exception e) {
//				return new AuthorizationDecision(false);
//			}

			// ✅ Ensure authentication check (optional but recommended)
			boolean isAuthenticated = authentication != null && authentication.get().isAuthenticated();
			boolean hasValidHeader = isValidHeader( request );
//			boolean hasValidRole = StringUtils.isNotBlank( role );
			if ( isAuthenticated && hasValidHeader ) {
				LOGGER.debug( "Request Authenticated:: X-Authenticated-User: {}, X-Authenticated-Role: {}", username, role );
				// Convert role to a list of GrantedAuthority
				List<GrantedAuthority> authorities = Collections.singletonList(new SimpleGrantedAuthority("ROLE_"+role));

				// Create Authentication object
				Authentication newAuth = new UsernamePasswordAuthenticationToken(username, null, authorities);

				// Store it in Security Context
				SecurityContextHolder.getContext().setAuthentication(newAuth);
			}
			else
			{
				LOGGER.error( "Authentication Header in not found: X-Authenticated-User {}, X-Authenticated-Role {}",
						username, role );
			}

			return new AuthorizationDecision(isAuthenticated && hasValidHeader );
		};
	}

	private boolean isValidHeader( HttpServletRequest request )
	{
		String username = request.getHeader( AUTHENTICATED_USER );
		String role = request.getHeader( AUTHENTICATED_ROLE );
		String requestService = request.getHeader("X-Authenticated-Service");
		boolean isHeaderValid = false;
		if ( StringUtils.isNotBlank( username ) && StringUtils.isNotBlank( role ) && StringUtils.isNotBlank( requestService ) )
		{
			if ( requestService.equalsIgnoreCase( "ZenFlow-Gateway" ) )
			{
				isHeaderValid = true;
			}
		}
		return isHeaderValid;
	}

	/**
     * Configures the password encoder.
     *
     * @return the configured PasswordEncoder
     */
	@Bean
	public PasswordEncoder passwordEncoder()
	{
		return new BCryptPasswordEncoder( 12 );
	}
}
