//package com.codehub.zenflow.auth.utils;
//
//import com.codehub.zenflow.auth.service.AuthUserDetailsService;
//import com.codehub.zenflow.auth.service.JwtService;
//import jakarta.servlet.FilterChain;
//import jakarta.servlet.ServletException;
//import jakarta.servlet.http.HttpServletRequest;
//import jakarta.servlet.http.HttpServletResponse;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.context.ApplicationContext;
//import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
//import org.springframework.security.core.context.SecurityContextHolder;
//import org.springframework.security.core.userdetails.UserDetails;
//import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
//import org.springframework.stereotype.Component;
//import org.springframework.web.filter.OncePerRequestFilter;
//
//import java.io.IOException;
//
///**
// * Filter that processes JWT authentication for each request.
// */
//@Component
//public class JwtAuthenticationFilter extends OncePerRequestFilter {
//
//	@Autowired
//	private ApplicationContext context;
//
//	@Autowired
//	private JwtUtils jwtUtils;
//
//	@Autowired
//	private JwtService jwtService;
//
//	/**
//	 * Filters incoming requests and processes JWT authentication.
//	 *
//	 * @param request     the HTTP request
//	 * @param response    the HTTP response
//	 * @param filterChain the filter chain
//	 * @throws ServletException if an error occurs during filtering
//	 * @throws IOException      if an I/O error occurs during filtering
//	 */
//	@Override
//	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response,
//			FilterChain filterChain) throws ServletException, IOException {
//		/*// Extract token from the "Authorization" header (expected format "Bearer <token>")
//		String header = request.getHeader("Authorization");
//		if (header != null && header.startsWith("Bearer ")) {
//			String token = header.substring(7);
//			if (jwtUtils.validateToken(token)) {
//				// Extract username and role from token
//				String username = jwtUtils.getUsernameFromToken(token);
//				Claims claims = Jwts.parser()
//						.verifyWith( jwtUtils.getSigningKey() )
//						.build()
//						.parseSignedClaims( token )
//						.getPayload();
//				String role = (String) claims.get("role");
//
//				// Create an authentication object with the extracted role
//				UsernamePasswordAuthenticationToken authenticationToken = new UsernamePasswordAuthenticationToken(
//						username, null, Collections.singletonList(new SimpleGrantedAuthority("ROLE_" + role))
//				);
//				// Set authentication in the context
//				SecurityContextHolder.getContext().setAuthentication(authenticationToken);
//			}
//		}
//		filterChain.doFilter(request, response);*/
//
//		// Extract token from the "Authorization" header (expected format "Bearer <token>")
//		String requestHeader = request.getHeader("Authorization");
//		String token = null;
//		String username = null;
//
//		if (requestHeader != null && requestHeader.startsWith("Bearer ")) {
//			token = requestHeader.substring(7);
//			username = jwtUtils.extractUserName(token);
//		}
//
//		// Validate the token and set the authentication in the context
//		if (username != null && SecurityContextHolder.getContext().getAuthentication() == null) {
//			UserDetails userDetails = context.getBean(AuthUserDetailsService.class).loadUserByUsername(username);
//			if (jwtService.validateToken(token, userDetails)) {
//				UsernamePasswordAuthenticationToken authenticationToken = new UsernamePasswordAuthenticationToken(
//						userDetails, null, userDetails.getAuthorities());
//				authenticationToken.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
//				SecurityContextHolder.getContext().setAuthentication(authenticationToken);
//			}
//		}
//		filterChain.doFilter(request, response);
//	}
//}
