package com.codehub.zenflow.auth.controller;

import com.codehub.zenflow.auth.domain.User;
import com.codehub.zenflow.auth.service.AuthUserService;
import com.codehub.zenflow.auth.service.dto.UserServiceRequest;
import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * Controller for handling authentication-related requests.
 */
@RestController
@RequestMapping("api/auth")
public class AuthController
{

	private static final Logger LOGGER = LogManager.getLogger( AuthController.class);

	@Autowired
	private AuthUserService authUserService;

    /**
     * Retrieves a list of all users.
     * Accessible only to users with the ADMIN role.
     *
     * @return a list of User objects
     */
	@PreAuthorize( "hasRole('ADMIN')" )
	@GetMapping("/users")
	public List<User> getUsers()
	{
		return authUserService.getUsers();
	}

    /**
     * Retrieves a user by their ID.
     * Accessible only to users with the ADMIN role.
     *
     * @param id the ID of the user to retrieve
     * @return a ResponseEntity containing the user data as a string
     */
	@PreAuthorize( "hasRole('ADMIN')" )
	@GetMapping("/user/{id}")
	public ResponseEntity<String> getUserById(@PathVariable long id)
	{
		LOGGER.debug( "User id received: {}", id );
		return authUserService.getUserById( id );
	}

    /**
     * Registers a new user.
     *
     * @param request the user data for registration
     * @return a ResponseEntity containing the registration status as a string
     */
	@PostMapping("/signup")
	public ResponseEntity<String> saveUser( UserServiceRequest request )
	{
		LOGGER.debug( "Sign-Up :: User Details received to be saved: {}",request );
		return authUserService.registerUserData( request );
	}

    /**
     * Authenticates a user.
     *
     * @param request the user data for authentication
     * @return a ResponseEntity containing the authentication status as a string
     */
	@PostMapping("/login")
	public ResponseEntity<Map<String,String>> loginUser(@RequestBody UserServiceRequest request)
	{
		LOGGER.debug( "Log-In :: User Details received to be verify: {}", request );
		return authUserService.loginUserData( request );
	}

    /**
     * Verifies a user's account.
     *
     * @param request the user data for verification
     * @return a ResponseEntity containing the verification status as a string
     */
	@GetMapping("/verifyUser")
	public ResponseEntity<String> verifyUserAccount(@RequestBody UserServiceRequest request)
	{
		return authUserService.verifyUserAccount( request );
	}

    /**
     * Recovers a user's account.
     *
     * @param request the user data for account recovery
     * @return a ResponseEntity containing the recovery status as a string
     */
	@PostMapping("/recover")
	public ResponseEntity<String> recoverAccount(@RequestBody UserServiceRequest request)
	{
		return authUserService.recoverUserAccount( request );
	}

}
