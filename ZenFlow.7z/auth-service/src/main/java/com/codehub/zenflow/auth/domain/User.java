package com.codehub.zenflow.auth.domain;

import jakarta.persistence.*;

/**
 * Entity class representing user credentials.
 */
@Entity
@Table(name = "user_auth_data")
public class User
{
    /**
     * The unique identifier for the user.
     */
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

    /**
     * The username of the user.
     */
	private String username;

    /**
     * The password of the user.
     */
	private String password;

    /**
     * The role of the user.
     */
	private String userRole;

    /**
     * The email of the user.
     */
	private String userEmail;

    /**
     * Gets the unique identifier for the user.
     *
     * @return the user ID
     */
	public Long getId()
	{
		return id;
	}

    /**
     * Sets the unique identifier for the user.
     *
     * @param id the user ID
     */
	public void setId( Long id )
	{
		this.id = id;
	}

    /**
     * Gets the username of the user.
     *
     * @return the username
     */
	public String getUsername()
	{
		return username;
	}

    /**
     * Sets the username of the user.
     *
     * @param username the username
     */
	public void setUsername( String username )
	{
		this.username = username;
	}

    /**
     * Gets the password of the user.
     *
     * @return the password
     */
	public String getPassword()
	{
		return password;
	}

    /**
     * Sets the password of the user.
     *
     * @param password the password
     */
	public void setPassword( String password )
	{
		this.password = password;
	}

    /**
     * Gets the role of the user.
     *
     * @return the user role
     */
	public String getUserRole()
	{
		return userRole;
	}

    /**
     * Sets the role of the user.
     *
     * @param userRole the user role
     */
	public void setUserRole( String userRole )
	{
		this.userRole = userRole;
	}

    /**
     * Gets the email of the user.
     *
     * @return the user email
     */
	public String getUserEmail()
	{
		return userEmail;
	}

    /**
     * Sets the email of the user.
     *
     * @param userEmail the user email
     */
	public void setUserEmail( String userEmail )
	{
		this.userEmail = userEmail;
	}

    /**
     * Returns a string representation of the user.
     *
     * @return a string representation of the user
     */
	@Override
	public String toString()
	{
		return "User{" +
				"id=" + id +
				", username='" + username + '\'' +
				", userRole='" + userRole + '\'' +
				", userEmail='" + userEmail + '\'' +
				'}';
	}
}
