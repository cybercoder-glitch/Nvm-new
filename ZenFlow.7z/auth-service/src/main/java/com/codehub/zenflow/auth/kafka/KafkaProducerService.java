package com.codehub.zenflow.auth.kafka;

import com.codehub.zenflow.kafka.event.UserCreateEvent;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

@Service
public class KafkaProducerService
{
	private final KafkaTemplate<String, UserCreateEvent> kafkaTemplate;

	public KafkaProducerService(KafkaTemplate<String, UserCreateEvent> kafkaTemplate)
	{
		this.kafkaTemplate = kafkaTemplate;
	}

	public void publishEvent(UserCreateEvent event)
	{
		kafkaTemplate.send( "user-event-topic", event );
	}

}
