package com.codehub.zenflow.kafka.consumer;

import org.springframework.kafka.annotation.KafkaListener;

public abstract class BaseKafkaConsumer<T> {

    @KafkaListener(topics = "#{'${kafka.topic.name:user-event-topic}'}", groupId = "#{'${kafka.consumer.group:user-service-group}'}")
    public void consumeEvent(T event) {
        handleEvent(event);
    }

    protected abstract void handleEvent(T event);
}
