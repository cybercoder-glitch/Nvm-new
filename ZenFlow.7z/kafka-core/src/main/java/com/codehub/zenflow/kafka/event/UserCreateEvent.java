package com.codehub.zenflow.kafka.event;

public class UserCreateEvent
{
	private Long userId;

	private String username;

	private String email;

	private String profileName;

	private String firstName;

	private String lastName;

	private String userRole;

	public Long getUserId()
	{
		return userId;
	}

	public void setUserId( Long userId )
	{
		this.userId = userId;
	}

	public String getUsername()
	{
		return username;
	}

	public void setUsername( String username )
	{
		this.username = username;
	}

	public String getEmail()
	{
		return email;
	}

	public void setEmail( String email )
	{
		this.email = email;
	}

	public String getProfileName()
	{
		return profileName;
	}

	public void setProfileName( String profileName )
	{
		this.profileName = profileName;
	}

	public String getFirstName()
	{
		return firstName;
	}

	public void setFirstName( String firstName )
	{
		this.firstName = firstName;
	}

	public String getLastName()
	{
		return lastName;
	}

	public void setLastName( String lastName )
	{
		this.lastName = lastName;
	}

	public String getUserRole()
	{
		return userRole;
	}

	public void setUserRole( String userRole )
	{
		this.userRole = userRole;
	}

	@Override
	public String toString()
	{
		return "UserCreateEvent{" +
				"userId=" + userId +
				", username='" + username + '\'' +
				", email='" + email + '\'' +
				", profileName='" + profileName + '\'' +
				", firstName='" + firstName + '\'' +
				", lastName='" + lastName + '\'' +
				", userRole='" + userRole + '\'' +
				'}';
	}
}

