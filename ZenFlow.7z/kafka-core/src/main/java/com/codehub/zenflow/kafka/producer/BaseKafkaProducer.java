package com.codehub.zenflow.kafka.producer;

import org.springframework.kafka.core.KafkaTemplate;

public class BaseKafkaProducer<T> {

    private final KafkaTemplate<String, T> kafkaTemplate;

    public BaseKafkaProducer(KafkaTemplate<String, T> kafkaTemplate) {
        this.kafkaTemplate = kafkaTemplate;
    }

    public void send(String topic, T message) {
        kafkaTemplate.send(topic, message);
    }
}
