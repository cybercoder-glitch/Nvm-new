package com.codehub.zenflow.weather.model;

public class Weather
{

}
