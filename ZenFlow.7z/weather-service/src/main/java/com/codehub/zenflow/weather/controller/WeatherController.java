package com.codehub.zenflow.weather.controller;

public class WeatherController
{

}
