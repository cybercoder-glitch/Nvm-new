package com.codehub.zenflow.weather.service.impl;

import com.codehub.zenflow.weather.service.api.WeatherService;

public class WeatherServiceImpl implements WeatherService
{

}
