package com.codehub.zenflow.weather.service.api;

public interface WeatherService
{

}
