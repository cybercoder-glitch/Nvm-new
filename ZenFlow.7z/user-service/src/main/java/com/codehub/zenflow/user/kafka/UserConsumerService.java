package com.codehub.zenflow.user.kafka;

import com.codehub.zenflow.kafka.event.UserCreateEvent;
import com.codehub.zenflow.user.entity.UserProfile;
import com.codehub.zenflow.user.repo.UserProfileRepository;
import jakarta.transaction.Transactional;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

@Service
public class UserConsumerService
{

	private final UserProfileRepository userProfileRepository;

	public UserConsumerService(UserProfileRepository userProfileRepository) {
		this.userProfileRepository = userProfileRepository;
	}

	@Transactional
	@KafkaListener(topics = "user-event-topic", groupId = "user-service-event-group")
	public void consumeUserCreatedEvent( UserCreateEvent event) {
		System.out.println("Received event: " + event);

		// Create user profile based on received event
		UserProfile profile = new UserProfile();
		profile.setUserId( event.getUserId() );
		profile.setEmail( event.getEmail() );
		profile.setFirstName( event.getFirstName() );
		profile.setLastName( event.getLastName() );

		try
		{
			userProfileRepository.save(profile);
		}
		catch ( Exception e )
		{
			e.printStackTrace();
		}
	}
}
