import React from 'react'
import { useNavigate } from 'react-router-dom';
import FloatingActionButton from "../components/FloatingActionButtons";
import "../css/FloatingActionButtons.css";
import Box from '@mui/material/Box';


const HomePage = () => {
  let navigate = useNavigate();
  return (
    <div><h1>Welcome To ZenFlow</h1>
        <Box className="fab-container" >
            <FloatingActionButton type="login"/>
            <FloatingActionButton type="signup"/>
        </Box>
    </div>
  )
}

export default HomePage;