import { Box, Button, Container, Grid2 } from '@mui/material'
import { DataGrid } from '@mui/x-data-grid';
import React, { useEffect, useState } from 'react'
import AccountMenu from '../components/AccountMenu';
// import { Container, Box, Grid2 } from '@mui/material'


  const columns = [
    { field: 'id', headerName: 'ID', width: 100 },
    { field: 'task', headerName: 'Task Name', width: 200 },
    { field: 'status', headerName: 'Status', width: 150 },
    { field: 'priority', headerName: 'Priority', width: 150 },
  ];

  const sampleRows = [
    { id: 1, task: 'Fix UI Bug', status: 'In Progress', priority: 'High' },
    { id: 2, task: 'Update API', status: 'Completed', priority: 'Medium' },
    { id: 3, task: 'Deploy App', status: 'Pending', priority: 'High' },
    { id: 4, task: 'Fix UI Bug', status: 'In Progress', priority: 'High' },
    { id: 5, task: 'Update API', status: 'Completed', priority: 'Medium' },
    { id: 6, task: 'Deploy App', status: 'Pending', priority: 'High' },
    { id: 7, task: 'Fix UI Bug', status: 'In Progress', priority: 'High' },
    { id: 8, task: 'Update API', status: 'Completed', priority: 'Medium' },
    { id: 9, task: 'Deploy App', status: 'Pending', priority: 'High' },
    { id: 10, task: 'Fix UI Bug', status: 'In Progress', priority: 'High' },
    { id: 11, task: 'Update API', status: 'Completed', priority: 'Medium' },
    { id: 12, task: 'Deploy App', status: 'Pending', priority: 'High' },
  ];


const Dashboard = () => {
    const [rows, setRows] = useState(sampleRows);

    useEffect(()=>{

    },[]);

  return (
    <Container maxWidth="lg">
      <Box sx={{
        display: "flex",
        justifyContent: "flex-end",
        padding: 2,
        marginRight: -20,
        marginBottom: 3,
      }}>
        <AccountMenu/>
      </Box>
      {/* Main Grid2 Container */}
      <Grid2 container spacing={2}>
        
        {/* Large left section */}
        <Grid2 xs={12} md={8}>
          <Box sx={{
            height: 550,
            width: 900, // Expands beyond normal width
            backgroundColor: "#818181",
            // display: "flex",
            // alignItems: "center",
            // justifyContent: "center",
            border: "2px solid black",
            position: "relative",
            left: "-20%",
          }} className="main-content">
            <Box sx={{
                display: "flex",
                alignItems: "center",
                justifyContent: "space-between",
                paddingRight: 3,
                paddingTop: 2,
            }}>
                <Box sx={{ fontSize: "22px", fontWeight: "bold", paddingLeft: 3, color: "black" }}>Tasks</Box>
                <Button variant="contained" sx={{
                    
                    background: '#8448d9',
                    '&:hover':{
                        backgroundColor: "#d4c1f1",
                    }
                }}>Add Task</Button>
            </Box>
            <Box sx={{ height: 400, width: '100%', backgroundColor: '#818181', marginTop: 2 }}>
                <DataGrid
                    rows={rows}           // Data rows
                    columns={columns}     // Column structure
                    // pageSize={5}          // Number of rows per page
                    // rowsPerPageOptions={[5,10,25,50]} // Pagination options
                    // pageSizeOptions={[5, 10, 25, { value: -1, label: 'All' }]}
                    // pageSizeOptions={[5, 10, 25]}
                    initialState={{
                        pagination: {
                          paginationModel: { pageSize: 5, page: 0 },
                        },
                      }}
                      pageSizeOptions={[5, 10, 25, { value: -1, label: 'All' }]}
                    disableSelectionOnClick // Disable row selection
                />
            </Box>
          </Box>
        </Grid2>

        {/* Right side sections */}
        <Grid2 xs={12} md={4} container spacing={2} direction="column">
          <Grid2 >
            <Box sx={{
                position: "relative",
                height: 170,
                width: "500%",
                backgroundColor: "#818181",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                border: "2px solid black",
                // right: "-20%",
                left: "-150%",
            }} className="small-box">Small Box 1</Box>
          </Grid2>
          <Grid2 >
            <Box sx={{
                position: "relative",
                height: 360,
                width: "500%",
                backgroundColor: "#818181",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                border: "2px solid black",
                left: "-150%",
            }} className="small-box">Small Box 2</Box>
          </Grid2>
        </Grid2>

      </Grid2>
    </Container>
  )
}

export default Dashboard