import * as React from 'react';
import { useNavigate } from 'react-router-dom';
import Box from '@mui/material/Box';
import Fab from '@mui/material/Fab';
import AddIcon from '@mui/icons-material/Add';
import EditIcon from '@mui/icons-material/Edit';
import NavigationIcon from '@mui/icons-material/Navigation';
import FavoriteIcon from '@mui/icons-material/Favorite';
import LockOpenRoundedIcon from '@mui/icons-material/LockOpenRounded';
import PersonAddIcon from '@mui/icons-material/PersonAdd';
// import './FloatingActionButtons.css'; // Import the CSS file

const FAB_TYPES = {
  add: { icon: <AddIcon />, color: 'primary', label: 'Add' },
  edit: { icon: <EditIcon />, color: 'secondary', label: 'Edit' },
  navigate: { icon: <NavigationIcon />, color: 'default', label: 'Navigate', extended: true },
  like: { icon: <FavoriteIcon />, color: 'default', label: 'Like', disabled: true },
  login: { icon: <LockOpenRoundedIcon sx={{ mr: 1 }}/>, color: 'primary', label: 'Login', variant: 'extended', route: '/login' }, 
  signup: { icon: <PersonAddIcon sx={{ mr: 1 }}/>, color: 'secondary', label: 'Signup', variant: 'extended', route: '/signup' }, 
};

export default function FloatingActionButtons({type}) {
  const fab = FAB_TYPES[type];

  const navigate = useNavigate();

  if (!fab) {
    console.warn(`Unknown FAB type: ${type}`);
    return null;
  }
  return (
      <Fab color={fab.color} aria-label={fab.label} variant={fab.variant} onClick={()=>navigate(fab.route)}>
        {fab.icon}
        {fab.label}
      </Fab>
  );
}
