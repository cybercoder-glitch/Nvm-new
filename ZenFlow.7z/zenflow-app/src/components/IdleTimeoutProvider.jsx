import React, { createContext, useContext, useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";

const IdleContext = createContext();
const INACTIVITY_LIMIT = 10 * 60 * 1000; // 10 minutes

export const IdleTimeoutProvider = ({ children }) => {
  const navigate = useNavigate();
  const [isLoggedOut, setIsLoggedOut] = useState(false);

  useEffect(() => {
    let logoutTimer;

    const resetTimer = () => {
      if (isLoggedOut) return;
      clearTimeout(logoutTimer);
      logoutTimer = setTimeout(() => {
        localStorage.removeItem("token");
        setIsLoggedOut(true);
        alert("You have been logged out due to inactivity.");
        navigate("/login");
      }, INACTIVITY_LIMIT);
    };

    const activityHandler = () => resetTimer();

    window.addEventListener("mousemove", activityHandler);
    window.addEventListener("keydown", activityHandler);
    window.addEventListener("click", activityHandler);
    window.addEventListener("scroll", activityHandler);
    window.addEventListener("touchstart", activityHandler);

    resetTimer();

    return () => {
      clearTimeout(logoutTimer);
      window.removeEventListener("mousemove", activityHandler);
      window.removeEventListener("keydown", activityHandler);
      window.removeEventListener("click", activityHandler);
      window.removeEventListener("scroll", activityHandler);
      window.removeEventListener("touchstart", activityHandler);
    };
  }, [navigate, isLoggedOut]);

  return <IdleContext.Provider value={null}>{children}</IdleContext.Provider>;
};

export const useIdleTimeout = () => useContext(IdleContext);
