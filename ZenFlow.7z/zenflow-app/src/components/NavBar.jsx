import React, { useState } from "react";
import { AppBar, Toolbar, Typography, IconButton, Button, Switch } from "@mui/material";
import { Menu, Brightness4, Brightness7, Logout } from "@mui/icons-material";
import { useNavigate } from "react-router-dom";

const NavBar = ({ darkMode, setDarkMode }) => {
    const navigate = useNavigate();

    // Handle Logout
    const handleLogout = () => {
        localStorage.removeItem("token"); // Remove JWT Token
        navigate("/login"); // Redirect to Login Page
    };

    return (
        <AppBar position="static" color={darkMode ? "default" : "primary"}>
            <Toolbar>
                {/* Menu Icon (For Sidebar if needed) */}
                <IconButton edge="start" color="inherit">
                    <Menu />
                </IconButton>

                {/* App Title */}
                <Typography variant="h6" sx={{ flexGrow: 1 }}>
                    ZenFlow
                </Typography>

                {/* Dark Mode Toggle */}
                <IconButton color="inherit" onClick={() => setDarkMode(!darkMode)}>
                    {darkMode ? <Brightness7 /> : <Brightness4 />}
                </IconButton>

                {/* Dashboard Button */}
                <Button color="inherit" onClick={() => navigate("/dashboard")}>
                    Dashboard
                </Button>

                {/* Logout Button */}
                <IconButton color="inherit" onClick={handleLogout}>
                    <Logout />
                </IconButton>
            </Toolbar>
        </AppBar>
    );
};

export default NavBar;
