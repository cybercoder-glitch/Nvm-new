import axios from 'axios';

const auth_api = axios.create({
  baseURL: import.meta.env.VITE_AUTH_API_URL, // Load the API URL from .env file
  // headers: {
  //   'Content-Type': 'application/json',
  // },
  withCredentials: true, // Include cookies for authentication if needed
});

export default auth_api;

