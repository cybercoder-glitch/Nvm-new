import axios from 'axios';

const task_api = axios.create({
  baseURL: import.meta.env.VITE_TASK_API_URL, // Load the API URL from .env file
  headers: {
    'Content-Type': 'application/json',
  },
  withCredentials: true, // Include cookies for authentication if needed
});

export default task_api;

