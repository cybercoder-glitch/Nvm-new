import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import * as yup from 'yup';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import { Person, Password, PersonAddAlt1 } from '@mui/icons-material';
import '../css/LoginForm.css';
import auth_api from '../utils/auth_api'

// Validation Schema using Yup
const schema = yup.object({
    username: yup.string().required("Username is required"),
    password: yup.string().min(6, "Password must be at least 6 characters").required("Password is required")
}).required();

const LoginForm = () => {
    let navigate = useNavigate();
    const [apiError, setApiError] = useState(null);

    const { register, handleSubmit, reset, setError, formState: { errors } } = useForm({
        resolver: yupResolver(schema)
    });

    const onSubmit = async (data) => {
        try {
            console.log(data);
            const response = await auth_api.post('/login', data);
            console.log(response);
            localStorage.setItem('token', response.data.token); // Store JWT in local storage
            navigate('/dashboard'); // Redirect after login
        } catch (error) {
            setError("username", { type: "manual", message: "Invalid username or password" });
            setApiError("Login failed. Please check your credentials.");
            reset({ username: "", password: "" });
        }
    };

    return (
        <div className='wrapper poppins-regular'>
            <form onSubmit={handleSubmit(onSubmit)}>
                <h1>Log In</h1>
                <div className="input-box">
                    <Person className='icon' />
                    <input type="text" placeholder="Username" {...register("username")} />
                </div>
                {errors.username && <p className="error-message">{errors.username.message}</p>}

                <div className="input-box">
                    <Password className='icon' />
                    <input type="password" placeholder="password" {...register("password")} />
                </div>
                {errors.password && <p className="error-message">{errors.password.message}</p>}
                
                {apiError && <p className="error-message">{apiError}</p>}

                <div className="remember-forgot">
                    <label><input type="checkbox" />Remember Me</label>
                    <a href="#">Forgot Password?</a>
                </div>
                <button type="submit">Login</button>

                <div className="register-link">
                    <p>
                        Don't have an account?  
                        <span className="signup-link" onClick={() => navigate('/signup')}>
                            Sign Up
                        </span>
                        <PersonAddAlt1 className='personIcon' />
                    </p>
                </div>
            </form>
        </div>
    );
};

export default LoginForm;
