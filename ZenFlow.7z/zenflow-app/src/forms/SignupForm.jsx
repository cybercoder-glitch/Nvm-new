import React from "react";
import { TextField, Button, Box, Typography, MenuItem } from "@mui/material";
import { useFormik } from "formik";
import * as Yup from "yup";
import auth_api from "../utils/auth_api";
import { useNavigate } from "react-router-dom";
import '../css/SignupForm.css';

const SignupForm = () => {
  const navigate = useNavigate();

  const formik = useFormik({
    initialValues: {
      username: "",
      email: "",
      role: "",
      password: "",
      confirmPassword: "",
    },
    validationSchema: Yup.object({
      username: Yup.string().required("Username is required"),
      email: Yup.string().email("Invalid email").required("Email is required"),
      role: Yup.string().required("Role is required"),
      password: Yup.string().min(6, "Password must be at least 6 characters").required("Password is required"),
      confirmPassword: Yup.string()
        .oneOf([Yup.ref("password"), null], "Passwords must match")
        .required("Confirm Password is required"),
    }),
    onSubmit: async (values) => {
      try {
        const signupResponse = await auth_api.post("/signup", values);
        console.log("Signup Successful", signupResponse.data);
        
        // Attempt login after successful signup
        if(signupResponse){
          const loginResponse = await auth_api.post("/login", {
            username: values.username,
            password: values.password,
          });
  
          const token = loginResponse.data.token;
          localStorage.setItem("authToken", token);
          console.log("Login Successful, Token Stored");
        }

        navigate("/dashboard");
      } catch (error) {
        console.error("Signup or Login Failed", error);
      }
    },
  });

  return (
    <div className="signup-container">
      <Typography variant="h4" sx={{ textAlign: "center", paddingTop: 5, color: "white", mb: 2 }}>
        Sign Up
      </Typography>
      <Box
        component="form"
        onSubmit={formik.handleSubmit}
        sx={{ display: "flex", flexDirection: "column", gap: 2, width: "480px", padding: 3, borderRadius: "10px" }}
      >
        {[
          { name: "username", label: "Username" },
          { name: "email", label: "Email Address" },
          { name: "password", label: "Password", type: "password" },
          { name: "confirmPassword", label: "Confirm Password", type: "password" },
        ].map((field) => (
          <div key={field.name}>
            <TextField
              label={field.label}
              variant="outlined"
              fullWidth
              type={field.type || "text"}
              {...formik.getFieldProps(field.name)}
              error={formik.touched[field.name] && Boolean(formik.errors[field.name])}
              helperText={formik.touched[field.name] && formik.errors[field.name]}
              InputLabelProps={{ style: { color: "rgb(170, 170, 170)" } }}
              InputProps={{
                style: { color: "white" },
                sx: {
                  "& .MuiOutlinedInput-notchedOutline": { borderColor: "rgba(255, 255, 255, .2)" },
                  "&:hover .MuiOutlinedInput-notchedOutline": { borderColor: "rgba(255, 255, 255, .5)" },
                  "&.Mui-focused .MuiOutlinedInput-notchedOutline": { borderColor: "white" },
                },
              }}
            />
          </div>
        ))}

        <TextField
          label="User Role"
          variant="outlined"
          select
          fullWidth
          {...formik.getFieldProps("role")}
          error={formik.touched.role && Boolean(formik.errors.role)}
          helperText={formik.touched.role && formik.errors.role}
          InputLabelProps={{ style: { color: "rgb(170, 170, 170)" } }}
          InputProps={{
            style: { color: "white" },
            sx: {
              "& .MuiOutlinedInput-notchedOutline": { borderColor: "rgba(255, 255, 255, .2)" },
              "&:hover .MuiOutlinedInput-notchedOutline": { borderColor: "rgba(255, 255, 255, .5)" },
              "&.Mui-focused .MuiOutlinedInput-notchedOutline": { borderColor: "white" },
            },
          }}
        >
          <MenuItem value="Admin">ADMIN</MenuItem>
          <MenuItem value="User">USER</MenuItem>
        </TextField>

        <Button
          type="submit"
          variant="contained"
          fullWidth
          sx={{
            backgroundColor: "black",
            borderRadius: "30px",
            color: "white",
            marginBottom: "10px",
            height: "50px",
            marginTop: "10px",
            "&:hover": { backgroundColor: "rgb(30, 30, 30)" },
          }}
        >
          SIGN UP
        </Button>
      </Box>
    </div>
  );
};

export default SignupForm;
