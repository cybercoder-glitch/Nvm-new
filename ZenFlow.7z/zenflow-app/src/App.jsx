import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import { BrowserRouter, Routes, Route } from 'react-router-dom'
import HomePage from './pages/HomePage'
import './App.css'
import LoginForm from './forms/LoginForm'
import SignupForm from './forms/SignupForm'
import PrivateRoute from './components/PrivateRoute'
import Dashboard from './pages/Dashboard'
import AccountMenu from './components/AccountMenu'
import { IdleTimeoutProvider } from './components/IdleTimeoutProvider'

function App() {
  

  return (
    
      <BrowserRouter>
        <IdleTimeoutProvider>
          <Routes>
            <Route path='/' element={<HomePage />}/> 
            <Route path='/login' element={<LoginForm />}/> 
            <Route path='/signup' element={<SignupForm/>}/>
            <Route element={<PrivateRoute/>}>
              <Route path="/dashboard" element={<Dashboard/>}/>
            </Route>
          </Routes>
        </IdleTimeoutProvider>
      </BrowserRouter>
  )
}

export default App
