package com.codehub.zenflow.gateway.jwt;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;

@Service
public class JwtService
{

	@Autowired
	private JwtUtils jwtUtils;

	/**
	 * Validates the given JWT token against the provided user details.
	 *
	 * @param token the JWT token to validate
	 * @return true if the token is valid, false otherwise
	 */
	public boolean validateToken(String token) {
		final String userName = jwtUtils.extractUserName(token);
		return (userName != null && !jwtUtils.isTokenExpired(token));
	}
}
