package com.codehub.zenflow.gateway.jwt;
/*
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.gateway.filter.GatewayFilter;
import org.springframework.cloud.gateway.filter.GatewayFilterChain;
import org.springframework.cloud.gateway.filter.GlobalFilter;
import org.springframework.core.Ordered;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Mono;

import java.util.List;

@Component
public class JwtAuthenticationFilter implements Ordered, GatewayFilter
{

    @Autowired
    private JwtUtils jwtUtils;

    @Autowired
    private JwtService jwtService;

    @Override
    public Mono<Void> filter( ServerWebExchange exchange, GatewayFilterChain chain) {
        ServerHttpRequest request = exchange.getRequest();
        System.out.println("================= Inside filter =================");
        // Allow authentication routes to pass through without validation
        if (request.getURI().getPath().matches("^/api/auth/(login|signup|recover)$")) {
            return chain.filter(exchange);
        }

        // Extract JWT from Authorization header
        List<String> authHeaders = request.getHeaders().get( HttpHeaders.AUTHORIZATION);
        if (authHeaders == null || authHeaders.isEmpty() || !authHeaders.get(0).startsWith("Bearer ")) {
            return unauthorizedResponse(exchange, "Missing or invalid Authorization header");
        }

        String token = authHeaders.get(0).substring(7); // Remove "Bearer "

        // Validate token
        if (!jwtService.validateToken(token)) {
            return unauthorizedResponse(exchange, "Invalid or expired token");
        }

        // Extract username & role
        String username = jwtUtils.extractUserName(token);
        String role = jwtUtils.extractUserRole(token);

        // Modify request to include authenticated user information
        ServerHttpRequest modifiedRequest = request.mutate()
                .header("X-Authenticated-User", username)
                .header("X-Authenticated-Role", role)
                .build();

        return chain.filter(exchange.mutate().request(modifiedRequest).build());
    }

    private Mono<Void> unauthorizedResponse(ServerWebExchange exchange, String message) {
        exchange.getResponse().setStatusCode( HttpStatus.UNAUTHORIZED);
        return exchange.getResponse().setComplete();
    }

    @Override
    public int getOrder() {
        return -1; // Ensures this filter runs first
    }
}*/

import org.springframework.cloud.gateway.filter.GatewayFilter;
import org.springframework.cloud.gateway.filter.GatewayFilterChain;
import org.springframework.cloud.gateway.filter.factory.AbstractGatewayFilterFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Mono;

import java.security.cert.X509Certificate;
import java.util.Base64;
import java.util.List;

@Component
public class JwtAuthenticationFilter extends AbstractGatewayFilterFactory<JwtAuthenticationFilter.Config> {

    public static class Config {
        // Configuration properties (if any)
    }

    private final JwtService jwtService;
    private final JwtUtils jwtUtils;

    public JwtAuthenticationFilter(JwtService jwtService, JwtUtils jwtUtils) {
        super(Config.class);
        this.jwtService = jwtService;
        this.jwtUtils = jwtUtils;
    }

    @Override
    public GatewayFilter apply(Config config) {
        return (exchange, chain) -> {
            ServerHttpRequest request = exchange.getRequest();

            // 🔍 Log the incoming request
            System.out.println("🔍 Incoming request: " + request.getURI().getPath());

            // Allow authentication routes to pass through without validation
            if (request.getURI().getPath().matches("^/api/auth/(login|signup|recover)$")) {
                System.out.println("✅ Public route: " + request.getURI().getPath());
                return chain.filter(exchange);
            }

            // Extract JWT from Authorization header
            List<String> authHeaders = request.getHeaders().get(HttpHeaders.AUTHORIZATION);
            if (authHeaders == null || authHeaders.isEmpty() || !authHeaders.get(0).startsWith("Bearer ")) {
                System.out.println("🚨 Unauthorized: Missing or invalid Authorization header");
                return unauthorizedResponse(exchange);
            }

            String token = authHeaders.get(0).substring(7); // Remove "Bearer "

            // Validate token
            if (!jwtService.validateToken(token)) {
                System.out.println("🚨 Unauthorized: Invalid or expired token");
                return unauthorizedResponse(exchange);
            }

            // Extract user details
            String username = jwtUtils.extractUserName(token);
            String role = jwtUtils.extractUserRole(token);

            System.out.println("✅ Authenticated User: " + username);
            System.out.println("✅ Authenticated Role: " + role);

            // Extract the client certificate from the SSL info.
//            X509Certificate[] certs = (X509Certificate[]) request.getSslInfo().getPeerCertificates();
//            if (certs == null || certs.length == 0) {
//                return unauthorizedResponse(exchange);
//            }
//            X509Certificate clientCert = certs[0];
//            String encodedCert;
//            try {
//                encodedCert = Base64.getEncoder().encodeToString(clientCert.getEncoded());
//            } catch (Exception e) {
//                return unauthorizedResponse(exchange);
//            }

            // Modify request to include authenticated user info
            ServerHttpRequest.Builder modifiedRequestBuilder = request.mutate()
                    .header("X-Authenticated-User", username)
                    .header("X-Authenticated-Role", role)
                    .header( "X-Authenticated-Service","ZenFlow-Gateway" );
//                    .header("X-Client-Cert", encodedCert);
            ServerHttpRequest modifiedRequest = modifiedRequestBuilder.build();

            // **Force header propagation**
            ServerWebExchange modifiedExchange = exchange.mutate().request(modifiedRequest).build();
            System.out.println("🔍 Headers after mutation: ");
            modifiedRequest.getHeaders().forEach((key, value) -> {
                System.out.println(key + " = " + value);
            });

            return chain.filter(modifiedExchange);
        };
    }

    private Mono<Void> unauthorizedResponse(ServerWebExchange exchange) {
        exchange.getResponse().setStatusCode( HttpStatus.UNAUTHORIZED);
        return exchange.getResponse().setComplete();
    }
}