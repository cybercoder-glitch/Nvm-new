package com.codehub.zenflow.gateway.config;

import com.codehub.zenflow.gateway.jwt.JwtAuthenticationFilter;
import com.codehub.zenflow.gateway.jwt.JwtService;
import com.codehub.zenflow.gateway.jwt.JwtUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.web.reactive.EnableWebFluxSecurity;
import org.springframework.security.config.web.server.SecurityWebFiltersOrder;
import org.springframework.security.config.web.server.ServerHttpSecurity;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.security.web.server.SecurityWebFilterChain;
import org.springframework.web.server.WebFilter;

@Configuration
@EnableWebFluxSecurity  // ✅ Correct annotation for WebFlux security
public class SecurityConfiguration {

	@Autowired
	private JwtService jwtService;

	@Autowired
	private JwtUtils jwtUtils;

	@Bean
	public SecurityWebFilterChain securityWebFilterChain(ServerHttpSecurity http) {
		http.csrf(ServerHttpSecurity.CsrfSpec::disable)
//				.authorizeExchange(exchanges -> exchanges
//						.pathMatchers(HttpMethod.POST, "/api/auth/signup", "/api/auth/login", "/api/auth/recover").permitAll()
//						.anyExchange().authenticated()
//				)
				.formLogin(ServerHttpSecurity.FormLoginSpec::disable)
				.httpBasic(ServerHttpSecurity.HttpBasicSpec::disable);

		return http.build();
	}
}
